<template>
    <div class="detect-task">
      <h1>SdkList</h1>
    </div>
  </template>
  
  <script lang="ts">
  export default {
    name: 'DetectTask'
  };
  </script>
  
  <style scoped>
  .detect-task {
    text-align: center;
    padding: 20px;
  }
  </style>