<template>
    <div class="home">
      <h1>Welcome to SDK Center</h1>
    </div>
  </template>
  
  <script lang="ts">
  export default {
    name: 'Home'
  };
  </script>
  
  <style scoped>
  .home {
    text-align: center;
    padding: 20px;
  }
  </style>