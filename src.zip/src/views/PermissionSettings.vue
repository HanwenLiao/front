<template>
    <div class="permission-settings">
      <h1>PermissionSettings</h1>
    </div>
</template>
  
  <script lang="ts">
  export default {
    name: 'PermissionSettings'
  };
  </script>
  
  <style scoped>
  .permission-settings {
    text-align: center;
    padding: 20px;
  }
  </style>